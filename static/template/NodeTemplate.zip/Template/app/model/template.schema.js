/**
 * Created by jsen on 2017/4/12.
 */

let mongoose = require('mongoose'),
    Schema = mongoose.Schema;


var ShopSchema = new Schema({
  _id : { type: String },                    //id
  name: {type:String},    // 游戏时间
  icon:{type:String},//分数
  goods:[{ type: Schema.Types.ObjectId, ref: 'goods' }],
  inTime:{type:Date}//录入时间
});

var GoodsSchema = new Schema({
  _id : { type: String },                    //id
  _creator : { type: String, ref: 'shop' },
  name: {type:String},    // 游戏时间
  icon:{type:String},//分数
  inTime:{type:Date}//录入时间
});

// findOne
// object.save
exports.goods = mongoose.model('goods', GoodsSchema);
exports.shop = mongoose.model('shop', ShopSchema);

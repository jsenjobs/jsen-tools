exports.shop = require('./template.schema').shop;
exports.goods = require('./template.schema').goods;
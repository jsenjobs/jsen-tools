exports.boot = function() {
	{{mongo_require}} require('./mongose.init').boot()
	{{redis_require}} require('./redis.init').boot()
}
let templatecontroller = require('./templatecontroller');
let appC = require('./app');

exports.boot = function(app) {
  app.post('/saveRecord', templatecontroller.saveRecord)
  app.get('/getRank', templatecontroller.getRank)

  app.get('/app/status', appC.status);
  app.get('/app/getLog', appC.getLog);
}
let log4js = require('log4js');
let logger = log4js.getLogger('ControllerTemplate');


exports.listShop = function(req, res) {
    logger.info('listShop Api Call');

    req.models.shop.listShop().then(result => {
        if (result) {
            return res.status(200).json(result);
        } else {
            return res.status(200).json({code:1, 'msg':'unknown'})
        }
    });
}

exports.listGoods = function(req, res) {
    logger.info('listGoods Api Call');

    if (!req.param('id')) {
      return res.status(200).json({code:1, msg:"参数错误"});
    }

    req.models.shop.listGoods(req.param('id')).then(result => {
        if (result) {
            return res.status(200).json(result);
        } else {
            return res.status(200).json({code:1, 'msg':'unknown'})
        }
    });
}

exports.addShop = function(req, res) {
    logger.info('addShop Api Call');

    if (!req.body.name || !req.body.icon) {
      return res.status(200).json({code:1, msg:"参数错误"});
    }

    req.models.shop.addShop(req.body.name, req.body.icon).then(result => {
        if (result) {
            return res.status(200).json(result);
        } else {
            return res.status(200).json({code:1, 'msg':'unknown'})
        }
    });
}

exports.addGoods = function(req, res) {
    logger.info('addGoods Api Call');

    if (!req.body.id || !req.body.name || !req.body.icon) {
      return res.status(200).json({code:1, msg:"参数错误"});
    }

    req.models.shop.addGoods(req.body.id , req.body.name, req.body.icon).then(result => {
        if (result) {
            return res.status(200).json(result);
        } else {
            return res.status(200).json({code:1, 'msg':'unknown'})
        }
    });
}
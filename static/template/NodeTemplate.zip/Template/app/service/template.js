/**
 * Created by jsen on 2017/4/19.
 */
let log4js = require('log4js');
let logger = log4js.getLogger('Service2048');
let _       = require('lodash');
let Promise = require("bluebird");
let fs = Promise.promisifyAll(require("fs"));
let UUID = require('uuid');

let moment = require('moment');

let Record = require('../model').record;

exports.saveRecord = function(username, phonenumber, stage, time, score) {

	return Record.findOne({'username':username}).then(exist => {
		if (exist) {
			let orC = [
				{'stage':{'$lt':stage}},
				{'stage':stage, 'time':{'$gt':time}},
				{'stage':stage, 'time':time, 'score':{'$lt':score}}
			]
				console.log(1)
			return Record.findOneAndUpdate({'username':username, '$or':orC}, {time:time,score:score,stage:stage,username:username,phonenumber:phonenumber,inTime:new Date()}).then(result => {
				console.log(result)
				return {code:0}
			})
		} else {
				console.log(2)
			let record = new Record();
			record._id = UUID.v1();
			record.time = time;
			record.score = score;
			record.stage = stage;
			record.username = username;
			record.phonenumber = phonenumber;
			record.inTime = new Date();
			return record.save().then(result => {
				if (result) {
					return {code:0};
				} else {
					return {code:1, 'msg':'保存失败'};
				}
			})
		}
	}) 
}
exports.fingTop = function(capacity) {
	var today = moment().format();
	var lm = moment().add(-30, 'days').format();
	return Record.find({'$and':[{'inTime':{'$gte':lm}}, {'inTime':{'$lt':today}}]}).sort({'stage':-1, 'time':1, 'score':-1}).limit(capacity).then(data => {
		if (data) {
			return {code:0, data:data}
		} else {
			return {code:1, msg:'查询出错'}
		}
	})
}
/*
exports.mock = function(phone) {
	let vCode = getVerifyCode() + '';
	return redis.SetValue(phone+vCode, vCode).then(eff => {
		if (eff == 1) {
			return {code:0, verify:vCode}
		} else {
			return {code:1, verify:vCode}
		}
	});
}
*/
let template = require('./template');
let models = {
	'template': template
}

exports.boot = function(app) {
	app.use(function(req,res, next) {
    if(!models.template) {
        return next(new Error('No Models Registed'));
    }
    req.models = models;
    return next();
})
}
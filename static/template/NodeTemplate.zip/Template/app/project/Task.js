let schedule = require("node-schedule");
let httpHelper = require('./httpHelper');
let log4js = require('log4js');
let logger = log4js.getLogger('Task');

exports.RegisterTask = function() {
	let rule = new schedule.RecurrenceRule();
	let times = [];
	for(var i=1; i<60; i+=10){
	　　times.push(i);
	}
	rule.second = times;
　　 var j = schedule.scheduleJob(rule, function(){
		httpHelper.get('http://'+process.env.Register+'/register/register?address='+process.env.Address+'&name='+process.env.name, 5000, (err, data) => {
				let json = '';
				try {
					json = JSON.parse(data);
				} catch(e) {}
				if (err || !json || !json.code == 0) {
					logger.info('no register server at:'+'http://'+process.env.Register+'/register/register?address='+process.env.Address+'&name='+process.env.name)
				} else {
					logger.info('register succeed at time:'+new Date())
				}
			})
　　 });

}